function quitarSITEC(){
    let pregunta = confirm("Seguro de quitar SITEC?")
    if(!pregunta == true){
        alert("SITEC Borrado...:(")
        let chi = document.getElementById("sitec")
        chi.innerHTML = "Shiiiiaaleee"

    }
}

function funcionAlerta(){
    alert("di clic");
}
//alert("Alerta en archivo externo javascript")
